import pandas as pd
import numpy as np

def process_data(df):
    """Process and clean data"""
    df = df.dropna()
    df['normalized'] = (df['value'] - df['value'].mean()) / df['value'].std()
    return df

if __name__ == '__main__':
    data = pd.read_csv('input.csv')
    result = process_data(data)
    result.to_csv('output.csv', index=False)
